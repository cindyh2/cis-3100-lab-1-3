//
//  main.cpp
//  lab 1 question 1
//
//  Created by Cindy Hernandez on 2/26/24.
//

#include <iostream>
using namespace std;

int main() {
    // use cout to write the statement
    // \n new line
    cout << "***************************************************\n" << endl;
    cout << "                       Welcome!" << endl;
    cout << "Please choose a number from the following options: " << endl;
    cout << " 1. Play the game!" << endl;
    cout << " 2. Demo the game!" << endl;
    cout << " 3. Exit \n" << endl;
    cout << "***************************************************" << endl;
    
    return 0;
}
