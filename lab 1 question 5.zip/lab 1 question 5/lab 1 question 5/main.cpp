//
//  main.cpp
//  lab 1 question 5
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
using namespace std;

int main() {
    // using string to input more characters
    string number, pverb, animal, place, money, name, noun, name2, color;
    
    // asking user to input respective questions
    cout << "enter a positive number below 4: " << endl;
    cin >> number;
    
    cout << "enter an animal: " << endl;
    cin >> animal;
    
    cout << "enter a past-tense verb: " << endl;
    cin >> pverb;
    
    cout << "enter a retail store: " << endl;
    // this will be considered a place
    cin >> place;
    
    cout << "enter a positive number below 50: " << endl;
    cin >> money;
    
    cout << "enter a name: " << endl;
    cin >> name;
    
    cout << "enter a noun: " << endl;
    cin >> noun;
    
    cout << "enter another name: " << endl;
    cin >> name2;
    
    cout << "enter a color: " << endl;
    cin >> color;
    
    // story based on what user input 
    cout << "One day, " << number << animal  << " went to the mall and " << pverb << " went shopping for a birthday gift. First, they went to " << place << " to look for a gift under $" << money << " but they couldn't agree on a gift option. " << name << " suggests the group go to " << noun << " to rethink their options. Everybody agrees and makes their way there. On the way there," << name2 << " sees a beautiful " << color << " card holder meets their budget. After a long day of looking for a gift, the group ends their day successfully and go home safely." << endl;
    
    return 0;
}
