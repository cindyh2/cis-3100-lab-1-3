//
//  main.cpp
//  lab 3 question 2
//
//  Created by Cindy Hernandez on 3/10/24.
//

#include <iostream>
using namespace std;

int main() {
    // declaring variables
    // set wage =2 bc $2 on first day + then doubled
    // day = 20 bc looking for 20th day
    double wage = 2;
    int days = 20;
    
    // x = day of work
    // using for loop to reach specific day
    for (int x = 2; x <= days; ++x) {
        // will double the amount
        wage *=2;
    }
    // print the final result
    cout << "The amount you will make on the 20th day is $" << wage << endl;
    
    return 0;
}
