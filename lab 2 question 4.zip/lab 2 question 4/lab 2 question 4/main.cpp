//
//  main.cpp
//  lab 2 question 4
//
//  Created by Cindy Hernandez on 3/10/24.
//

#include <iostream>
using namespace std;

int main() {
    // declare variables
    char starter, choice, response;
    
    // adventure based off pokemon franchise, will only have 2 options for choices instead of 3
    cout << "Welcome to your first adventure!" << endl;
    cout << "Choose a starter: 1 for Charmander or 2 for Pikachu" << endl;
    // storing the input
    cin >> starter;
    
    // used an 'if' statement to prevent user from inputting a number beside 1 or 2
    if (starter == '1' || starter == '2') {
        cout << "Great! Your journey has begun! \n " << endl;
        
        cout << "As you are walking through Route 1, a wild Pidgey appears. What will you do? Choose an option: \n 1. Catch the Pokemon.\n 2. Battle the Pokemon.\n 3. Run away."  << endl;
        // store input
        cin >> choice;
        
        // type if and else statements corresponding to their choices
        // each choice has a different answer
        if (choice == '1') {
            cout << "You threw a Pokeball. The Pidgey is caught! You now have 2 Pokemon in your party. \n" << endl;
        } else if (choice == '2') {
            cout << "You and your starter fought the Pidgey and won. Your Pokemon has leveled up! \n" << endl;
        } else if (choice == '3') {
            cout << "You have fled the battle. \n" << endl;
        }
        
        // next question for the user
        cout << "You have reached the end of Route 1. You have now reached Route 2. \n You see some patches of grass and some friendly trainers. What would you like to do?: \n 1. Talk to some trainers. \n 2. Go in the grass. \n 3. Go rest at the Pokemon Center. \n" << endl;
        // store input
        cin >> response;
        
        // reponses based off input choice
        // used brackets to get more lines controlled by 1 control statement
        if (response == '1') {
            cout << "You talk to two trainers. The first trainer gives you advice about using items. The second trainer gives you a free fishing rod. \n" << endl;
            cout << "You decide to explore further and talk to more trainers. \n" << endl;
        } else if (response == '2') {
            cout << "You battled some Pokemon in the grass. Your Pokemon has leveled up 5 levels. " << endl;
            cout << "You decided to heal up your Pokemon and find some trainers in the area. \n" << endl;
        } else if (response == '3') {
            cout << "You and your Pokemon go rest at the Pokemon Center. \n" << endl;
        }
        // the end of the adventure
        cout << "You have finished your adventure. See you next time! \n" << endl;
    }
    
    // response if user doesnt input 1 or 2
    else
        cout << "Try again. " << endl;
    
    return 0;
}
