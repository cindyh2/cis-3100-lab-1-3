//
//  main.cpp
//  lab 3 question 5
//
//  Created by Cindy Hernandez on 3/10/24.
//

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

int main() {
    int x=15, y=15, z; // Explorer’s coordinates + z for steps taken
    int x1, y1; // Treasure’s coordinates
    char direction;
    float distance;
    bool treasure=false;
    
    srand(time(0)); // secretly seed the rand function !
    x1=rand( ) % 30 + 1; // set X1 to random between 1 and 30
    y1=rand( ) % 30 + 1; // set y1 to random between 1 and 30
    
    // write loop to find the treasure
    while (!treasure) {
        cout << "Please enter direction (n,s,e,w), or x to exit: " << endl;
        cin >> direction;
        
        // use letter to determine user direction
        // break needed to end
        switch (direction) {
                // y coord increase
            case 'n':
                y++;
                break;
                // x coord increase
            case 'e':
                x++;
                break;
                // y coord decrease
            case 's':
                y--;
                break;
                // x coord decrfease
            case 'w':
                x--;
                break;
                // if user wants to exit
            case 'x':
                cout << "Now exiting treasure hunt... " << endl;
                break;
        }
        
        // formula to find distance
        distance=sqrt(static_cast<double>((x-x1)*(x-x1)+(y-y1)*(y-y1)));
        //displaying treasure distance
        cout << "Your distance from the treasure is: " << treasure << endl;
        // displaying user coordinates
        cout << "Your current coordinates are: (" << x <<", " << y << ")" << endl;
        
        // if statement for treasure found
        if (y == y1 && x == x1) {
            cout << "The treasure has been found. " << endl;
            treasure=true;
        }
    }
    
    // z = steps counter
    z++;
    // steps taken total to get treasure
    cout << "Total steps taken for treasure: " << z << endl;
    
    return 0;
}
