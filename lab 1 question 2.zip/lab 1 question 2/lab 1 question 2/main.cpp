//
//  main.cpp
//  lab 1 question 2
//  Created by Cindy Hernandez on 3/2/24.
/*
 Write a C++ program that will calculate the average of four numbers that are stored in variables. The
 variables are all of the data type: double. The values that are stored are 578, 986, 1066, and 714.
 Display a message showing the sum of all four numbers
 (ex. The sum of those numbers is ___.”)
 On the next line, display the average of all four numbers
 (ex. –
 “The average of those numbers is ___.”)
 */
//

#include <iostream>
using namespace std;

int main() {
    
    // double for number
    double num1 = 578;
    double num2 = 986;
    double num3 = 1066;
    double num4 = 714;
    
    double sum;
    double average;
    
    // equation to calculate
    sum = num1 + num2 + num3 + num4;
    average = sum / 4;
    
    // statements to show results
    cout << "The sum of those numbers is: " << sum << endl;
    cout << "The average of those numbers is: " << average << endl;
    
    return 0;
}
