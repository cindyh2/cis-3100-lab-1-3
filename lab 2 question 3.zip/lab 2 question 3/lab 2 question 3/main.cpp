//
//  main.cpp
//  0222 notes 4
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
using namespace std;

int main() {
    // declaring the variables to store the characters
    char c1, c2, c3;
    
    // prompt the user to enter data
    cout << "Enter 3 characters" << endl;
   
    // can also do individual lines of cin as " cin >> x "
    cin >> c1 >> c2 >> c3;
    
    cout << " first character " << c1 << endl;
    cout << " second character " << c2 << endl;
    cout << " third character " << c3 << endl;
    
    // is c1 is the smallest character
    if (c1 < c2 && c1 < c3)
        cout << c1 << " is the smallest " << endl;
    
    // is c2 the smallest character
    else if (c2 < c1 && c2 < c3)
        cout << c2 << " is the smallest " << endl;
    
    // is c3 the smallest character
    else
        cout << c3 << " is the smallest " << endl;
    
    // is  c1 the middle character
    if ((c1 > c2 && c1 < c3) || (c1 < c2 && c1 > c3))
        cout << c1 << " is the middle " << endl;
    
    // is c2 the middle character
    else if ((c2 > c1 && c2 < c3) || (c2 < c1 && c2 > c3))
        cout << c2 << " is the middle " << endl;
    
    // is c3 the smallest character
    else
        cout << c3 << "is the middle " << endl;
    
    // is c1 the biggest character
    if (c1 > c2 && c1 > c3)
        cout << c1 << " is the biggest " << endl;
    
    // is c2 the biggest character
    else if (c2 > c1 && c2 > c3)
        cout << c2 << " is the biggest " << endl;
    
    // is c3 the biggest character
    else
        cout << c3 << " is the biggest " << endl;
        
    return 0;
}
