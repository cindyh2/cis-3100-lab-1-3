//
//  main.cpp
//  lab 3 question 1
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
using namespace std;

int main() {
    // declaring intervals
    int num;

    // ask for user input
    cout << "Enter a number: " << endl;
    cin >> num;

    // set the code so that no number less than 0 can be entered
    if (num > 0) {
        // de-increment the input number
        while (num > 0) {
            cout << "It is now " << --num << "." << endl;
        }
    } else {
        cout << "Try again." << endl;
    }

    return 0;
}
