//
//  main.cpp
//  lab 1 question 3
//  Created by Cindy Hernandez on 3/2/24.
/*
 Write a C++ program that calculates the average of four numbers – just like in the previous exercise –
 but this time ask the user to enter which four numbers to calculate. You will have to use the cin
 command to get all four numbers from the user.
 Sample Output:
 Enter the first number: (number1)
 Enter the second number: (number2)
 Enter the third number: (number3)
 Enter the fourth number: (number4)
 The average of these numbers is: (average)
 */

#include <iostream>
using namespace std;

int main() {
    // double for number
    double num1, num2, num3, num4, average;
    
    // ask user to input a number
    cout << "Enter the first number: " << endl;
    cin >> num1;
    cout << "Enter the second number: " << endl;
    cin >> num2;
    cout << "Enter the third number: " << endl;
    cin >> num3;
    cout << "Enter the fourth number: " << endl;
    cin >> num4;
    
    // calculating the average
    average = (num1 + num2 + num3 + num4)/4;
    
    // showing the results
    cout << "The average of these numbers is: " << average << endl;
    
    return 0;
}
