//
//  main.cpp
//  lab 2 question 2
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    // setting precision
    cout << fixed << setprecision(2);
    
    // determing variables
    double income, netsalary, annualsalary;
    
    // input statement
    cout << "Enter salary amount: $" << endl;
    cin >> annualsalary;
    
    // setting up statements based of ranking of income and percentages
    if (annualsalary<=12000) {
        income = .06 * annualsalary;
        netsalary = annualsalary - income;
    } else if (annualsalary<=38000) {
        income = .27 * annualsalary;
        netsalary = annualsalary - income;
    } else {
        income = .39 * annualsalary;
        netsalary = annualsalary - income;
    }
    // input statements to show final results
    cout << "This year you paid $" << income << "dollars in tax. " << endl;
    cout << "So your net salary after taxes taken out is $" << netsalary << endl;
    
    // was unable to finish question and add corrections
    return 0;
}
