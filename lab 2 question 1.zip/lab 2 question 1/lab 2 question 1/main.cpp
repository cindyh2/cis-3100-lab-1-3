//
//  main.cpp
//  lab 2 question 1
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
using namespace std;

int main() {
    // ask for the temperature
    int temp;
    cout << "What is the temperature today in Farhrenheit?: ";
    cin >> temp;
    
    //see how the temperature feels today
    if (temp <= 40)
        cout << "It is very cold today!" << endl;
    
    else if (temp >=80)
        cout << "It is very hot today!" << endl;
    
    // appears when the temperature is between 40 and 80 degrees
    else
        cout << "It is a beautiful day outside!" << endl;
    
    return 0;
}
