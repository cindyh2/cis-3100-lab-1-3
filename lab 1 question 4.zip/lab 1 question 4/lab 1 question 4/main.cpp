//
//  main.cpp
//  lab 1 question 4
//
//  Created by Cindy Hernandez on 3/2/24.
//

#include <iostream>
#include <iomanip>
using namespace std;


int main() {
    cout << fixed << setprecision(2);
    
    // int for # w/o decimal, double for the rest
    int numofshares;
    double currentprice, purchaseprice, profit;
    
    // asking user for the amount of shares, price, and current price
    cout << "How many shares were purchased?: " << endl;
    cin >> numofshares;
    
    cout << "What was the price of shares when purchased?: " << endl;
    cin >> purchaseprice;
    
    cout << "What is the current price of shares?: " << endl;
    cin >> currentprice;
    
    // calculating profit
    profit = (numofshares * currentprice)-(numofshares * purchaseprice);
    
    // displaying results
    cout << "You have made a profit of $" << profit << " dollars since you bought " << numofshares << " shares of this stock." << endl;
    
    return 0;
}
