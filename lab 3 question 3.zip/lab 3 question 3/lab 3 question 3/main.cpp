//
//  main.cpp
//  lab 3 question 3
//
//  Created by Cindy Hernandez on 3/10/24.
//

#include <iostream>
using namespace std;

int main() {
    // determine variables, double bc nnumber input
    double loanamt, apr, monthly;
    
    // asking for student loan amount
    cout << "How much is owed in student loan debt?: " << endl;
    cin >> loanamt;
    
    // asking for annual interest rate
    cout << "What is the annual interest rate (APR)? Insert as percentage: " << endl;
    cin >> apr;
    
    // asking monthly amount
    cout << "What is the monthly pay amount: " << endl;
    cin >> monthly;
    
    // charged monthly apr
    double monthlyapr = ((apr/100)/12);
    
    // determining variables for decreasing loan amount
    int months = 0;
    double remainingamt = loanamt;
    
    // loop for the loan to be paid off
    while (remainingamt > 0) {
        double interest = remainingamt * monthlyapr;
        
        // formula to find amount after payment
        remainingamt = (interest + remainingamt) - monthly;
        
        // increase months
        months++;
    }
    
    cout << "The remaining amount is " << remainingamt << endl;
    
    return 0;
}
